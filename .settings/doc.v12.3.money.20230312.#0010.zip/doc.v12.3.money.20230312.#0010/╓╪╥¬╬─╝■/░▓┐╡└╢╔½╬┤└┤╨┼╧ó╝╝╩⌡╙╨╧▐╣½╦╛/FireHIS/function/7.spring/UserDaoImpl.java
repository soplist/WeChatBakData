package com.blue.dao.impl;

import com.blue.dao.IUserDao;

public class UserDaoImpl implements IUserDao {

	@Override
	public void test() {
		// TODO Auto-generated method stub
		System.out.println("call test finish!!!");
	}
	
}
