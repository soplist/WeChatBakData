package com.blue.service.impl;

import com.blue.dao.IUserDao;
import com.blue.service.IUserService;

public class UserServiceImpl implements IUserService {

	private IUserDao userDao;
	public IUserDao getUserDao() {
        return userDao;
    }
    public void setUserDao(IUserDao userDao) {
        this.userDao = userDao;
    }
	@Override
	public void test() {
		// TODO Auto-generated method stub
		userDao.test();
	}
      
}
