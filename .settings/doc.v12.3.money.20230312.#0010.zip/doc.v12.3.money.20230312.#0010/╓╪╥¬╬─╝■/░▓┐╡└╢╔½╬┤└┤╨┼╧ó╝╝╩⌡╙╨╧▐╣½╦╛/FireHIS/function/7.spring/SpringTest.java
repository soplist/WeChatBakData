package com.blue.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.blue.dao.IUserDao;
import com.blue.service.IUserService;
import com.blue.util.PathUtil;
import com.blue.util.XmlUtil;

public class SpringTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		XmlUtil xu = new XmlUtil();
		// TODO Auto-generated method stub
		String path = xu.getPath(PathUtil.spring);
		//String newPath = path.replaceAll("/", "\\");
		ApplicationContext act = new FileSystemXmlApplicationContext(path);
        IUserService us = (IUserService) act.getBean("userServiceImpl");
        us.test();
		//IUserDao ud = (IUserDao) act.getBean("UserDaoImpl");
		//ud.test();
		
    
	}

}
