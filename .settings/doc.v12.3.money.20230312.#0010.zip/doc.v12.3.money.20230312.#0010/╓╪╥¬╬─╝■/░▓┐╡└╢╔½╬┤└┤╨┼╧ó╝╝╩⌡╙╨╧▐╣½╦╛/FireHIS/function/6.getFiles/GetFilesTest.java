package com.blue.test;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.blue.util.PathUtil;
import com.blue.util.XmlUtil;

public class GetFilesTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        PathUtil pu = new PathUtil();
        XmlUtil xu = new XmlUtil();
        GetFilesTest gft = new GetFilesTest();
        
        String path = xu.getPath(pu.xmls);
        List<String> names = gft.getFileNames(path);
        
        for (String string : names) {
			System.out.println(string);
		}
	}

	private List<String> getFileNames(File file, List<String> fileNames) {
        File[] files = file.listFiles();
        for (File f : files) {
            if (f.isDirectory()) {
                getFileNames(f, fileNames);
            } else {
                fileNames.add(f.getName());
            }
        }
        return fileNames;
    }
	
	private List<String> getFileNames(String path) {
        File file = new File(path);
        if (!file.exists()) {
            return null;
        }
        List<String> fileNames = new ArrayList<>();
        return getFileNames(file, fileNames);
    }
}
