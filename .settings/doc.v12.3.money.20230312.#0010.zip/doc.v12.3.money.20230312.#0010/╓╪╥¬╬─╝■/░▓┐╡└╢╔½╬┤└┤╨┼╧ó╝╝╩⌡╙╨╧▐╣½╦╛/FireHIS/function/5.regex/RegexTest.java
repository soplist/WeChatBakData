package com.blue.test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String fname1 = "menuFunction_1.xml";
		String fname2 = "menuFunction_2.xml";
		String fname3 = "monuFunction_2.xml";
		
		RegexTest rt = new RegexTest();
		rt.matchesMenuStart(fname1);
		rt.matchesMenuStart(fname2);
		rt.matchesMenuStart(fname3);
	}
	
	public boolean matchesMenuStart(String s){
		String pattern = "menu(.*?)";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(s);
        if (m.matches()) {
        	System.out.println("true");
        	return true;
        }
        else{
        	System.out.println("false");
        	return false;
        }
	}

}
