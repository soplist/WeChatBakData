package com.blue.test;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.Iterator;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class Dom4jTest {
	
	Document document=null;

	private void getDocument(String path) {
		SAXReader saxReader = new SAXReader();
	    try {
	        document = saxReader.read(new File(path));
	    } catch (DocumentException e) {
	        throw new RuntimeException(e);
	    }
	}

	private void showInfo() {
        Element root = document.getRootElement();
        List<Element> elements = root.elements();
        
        for (Element element : elements) { 
            String s = null;

            String name = element.getName();//�õ�Ԫ����
            String id = element.attributeValue("id");//�õ�Ԫ�ص����Ե�ֵ

            s = "{" + name + ":" + "id=" + id;

            List<Element> childs = element.elements();//Ԫ�ص���Ԫ�ؼ���
            for (Element chileElement : childs) { 
                String childName = chileElement.getName();
                String childContent = chileElement.getText();//�õ���Ԫ������

                s += "\n\t\t" + childName + "=" + childContent + "}";
            }
            System.out.println(s);
        }
    }
	
	public String getI18nPath(){
		URL i18nPath = new Dom4jTest().getClass().getClassLoader().getResource("com/blue/xml/i18n.xml"); 
		
		String path = null;
		try {
			path = URLDecoder.decode(i18nPath.getPath(),"utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(path);
		return path;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dom4jTest test = new Dom4jTest();
		String i18nPath = test.getI18nPath();
		test.getDocument(i18nPath);
		test.showInfo();
	}
}
