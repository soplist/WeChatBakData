package com.blue.test;

import org.apache.log4j.Logger;



public class Log4jTest {
	private static Logger logger=Logger.getLogger(Log4jTest.class); 
    public static void main(String[] args) {
        for(int i=0;i<10;i++){
            logger.info("Info");
            logger.debug("debug");
            logger.error("error");
            logger.fatal("fatal");
            logger.warn("warn");
            System.out.println("----------------- "+i+"   ---------------------");
        }
    }
}
