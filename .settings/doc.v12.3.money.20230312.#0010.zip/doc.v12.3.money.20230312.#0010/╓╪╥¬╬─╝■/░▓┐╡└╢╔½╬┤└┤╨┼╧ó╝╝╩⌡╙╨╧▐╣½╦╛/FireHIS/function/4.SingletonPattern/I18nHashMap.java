package com.blue.util;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.blue.test.Dom4jTest;

public class I18nHashMap extends HashMap<String,String> {
	
	private static I18nHashMap INSTANCE;
	Document document=null;
	
    private I18nHashMap(){

    }

    public static I18nHashMap getInstance(){
        if(INSTANCE == null){
            INSTANCE = new I18nHashMap();
            INSTANCE.getDocument(INSTANCE.getI18nPath());
            INSTANCE.insertValue();
        }
        return INSTANCE;
    }
    
    private void getDocument(String path) {
		SAXReader saxReader = new SAXReader();
	    try {
	        document = saxReader.read(new File(path));
	    } catch (DocumentException e) {
	        throw new RuntimeException(e);
	    }
	}

	private void insertValue() {
        Element root = document.getRootElement();
        List<Element> elements = root.elements();
        
        for (Element element : elements) { 
            String name = element.getName();//�õ�Ԫ����
            String id = element.attributeValue("id");//�õ�Ԫ�ص����Ե�ֵ

            List<Element> childs = element.elements();//Ԫ�ص���Ԫ�ؼ���
            for (Element e : childs) { 
                String ename = e.getName();
                String content = e.getText();//�õ���Ԫ������

                if(ename.equals(CommonString.EN)){
                    this.put(id+"-english", content);
                }
                else if(ename.equals(CommonString.CN)){
                	this.put(id+"-chinese", content);
                }
            }
        }
    }
	
	public String getI18nPath(){
		URL i18nPath = new Dom4jTest().getClass().getClassLoader().getResource(PathUtil.i18n); 
		
		String path = null;
		try {
			path = URLDecoder.decode(i18nPath.getPath(),"utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(path);
		return path;
	}
}
