package com.blue.util;

import java.util.Iterator;
import java.util.Map;

public class InitProgram {
	
	private I18nHashMap i18nHashMap;

	public void initI18n(){
		i18nHashMap = I18nHashMap.getInstance();
	}
	
	public void i18nIterator(){
		Iterator<Map.Entry<String, String>> iterator = i18nHashMap.entrySet().iterator();
        while (iterator.hasNext()) {
        	Map.Entry<String, String> entry = iterator.next();
            System.out.println("key:" + entry.getKey() + ",vaule:" + entry.getValue());
        }
    }
	
	public static void main(String[] args) {
		InitProgram test = new InitProgram();
		test.initI18n();
		test.i18nIterator();
	}
}
